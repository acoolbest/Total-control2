#include "pcname.h"

PcName::PcName()
{
}
