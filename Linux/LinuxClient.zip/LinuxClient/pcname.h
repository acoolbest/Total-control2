#ifndef PCNAME_H
#define PCNAME_H

#include <QDesktopServices>

class PcName : public QDesktopServices
{
public:
    PcName();
};

#endif // PCNAME_H
